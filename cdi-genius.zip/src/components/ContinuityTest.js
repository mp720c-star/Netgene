import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { recordContinuityResult } from '../store/sessionSlice';
import { styles } from '../styles';

export default function ContinuityTest() {
  const dispatch = useDispatch();
  const model = useSelector((s) => s.session.selectedModel);

  return (
    <View style={styles.panel}>
      <Text style={styles.title}>Continuity Test (D-020)</Text>
      <Text style={styles.paragraph}>
        Verify power & ground continuity for model: {model?.model_id}
      </Text>

      <View style={{ flexDirection: 'row', marginTop: 12 }}>
        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#2e7d32' }]}
          onPress={() => dispatch(recordContinuityResult({ pass: true }))}
        >
          <Text style={styles.buttonText}>Pass</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#c62828', marginLeft: 12 }]}
          onPress={() => dispatch(recordContinuityResult({ pass: false }))}
        >
          <Text style={styles.buttonText}>Fail</Text>
        </TouchableOpacity>
      </View>

      <Text style={[styles.note, { marginTop: 16 }]}>
        Tip: use a digital multimeter in continuity mode between the instructed pins.
      </Text>
    </View>
  );
}
